package BlackJack.view;

public enum Action {
	Play,
	Hit,
	Stand,
	Quit,
	Default
}
