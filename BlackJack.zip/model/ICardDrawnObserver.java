package BlackJack.model;

public interface ICardDrawnObserver {
	public void update();
}
