# Workshop-3
The third workshop for OOADUML. All work done by Björn Elmqvist, excepts for the parts made by the course management people, of course.

To run the program, use Elcipse and navigate to Program.java. Now, press Alt + Shift + X, J to run it. Attempts to create a jar file have been made, but they have failed. It should be runnable.